--
-- PostgreSQL database dump
--

\restrict h6TlP8SXv3k9SWz7NR9u3uEdfoK1MpBTO6TIDtALHAApazPjrD3VVEJ2Xj4vvQc

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_preferences DROP CONSTRAINT IF EXISTS user_preferences_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.saved_views DROP CONSTRAINT IF EXISTS saved_views_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.parameter_changes DROP CONSTRAINT IF EXISTS parameter_changes_parameter_id_fkey;
ALTER TABLE IF EXISTS ONLY public.evaluations DROP CONSTRAINT IF EXISTS evaluations_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.evaluations DROP CONSTRAINT IF EXISTS evaluations_parameter_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_user_id_fkey;
DROP INDEX IF EXISTS public.users_username_unique;
DROP INDEX IF EXISTS public.user_sessions_expire_idx;
DROP INDEX IF EXISTS public.saved_views_user_name_unique;
DROP INDEX IF EXISTS public.parameters_name_unique;
DROP INDEX IF EXISTS public.evaluations_period_idx;
DROP INDEX IF EXISTS public.evaluations_parameter_idx;
DROP INDEX IF EXISTS public.audit_log_user_idx;
DROP INDEX IF EXISTS public.audit_log_occurred_idx;
DROP INDEX IF EXISTS public.audit_log_entity_idx;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.user_preferences DROP CONSTRAINT IF EXISTS user_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.students DROP CONSTRAINT IF EXISTS students_student_code_key;
ALTER TABLE IF EXISTS ONLY public.students DROP CONSTRAINT IF EXISTS students_pkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_pkey;
ALTER TABLE IF EXISTS ONLY public.schema_migrations DROP CONSTRAINT IF EXISTS schema_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.saved_views DROP CONSTRAINT IF EXISTS saved_views_pkey;
ALTER TABLE IF EXISTS ONLY public.parameters DROP CONSTRAINT IF EXISTS parameters_pkey;
ALTER TABLE IF EXISTS ONLY public.parameter_changes DROP CONSTRAINT IF EXISTS parameter_changes_pkey;
ALTER TABLE IF EXISTS ONLY public.parameter_changes DROP CONSTRAINT IF EXISTS parameter_changes_parameter_id_period_number_scope_key;
ALTER TABLE IF EXISTS ONLY public.evaluations DROP CONSTRAINT IF EXISTS evaluations_student_id_parameter_id_period_number_key;
ALTER TABLE IF EXISTS ONLY public.evaluations DROP CONSTRAINT IF EXISTS evaluations_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_sessions;
DROP TABLE IF EXISTS public.user_preferences;
DROP TABLE IF EXISTS public.students;
DROP TABLE IF EXISTS public.settings;
DROP TABLE IF EXISTS public.schema_migrations;
DROP TABLE IF EXISTS public.saved_views;
DROP TABLE IF EXISTS public.parameters;
DROP TABLE IF EXISTS public.parameter_changes;
DROP TABLE IF EXISTS public.evaluations;
DROP TABLE IF EXISTS public.audit_log;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid,
    actor text NOT NULL,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    details jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: evaluations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evaluations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    student_id uuid NOT NULL,
    parameter_id uuid NOT NULL,
    period_number integer NOT NULL,
    value numeric,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    locks_at timestamp with time zone NOT NULL,
    CONSTRAINT evaluation_period_positive CHECK ((period_number >= 1))
);


--
-- Name: parameter_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parameter_changes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    parameter_id uuid NOT NULL,
    period_number integer NOT NULL,
    scope text NOT NULL,
    action text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT change_action_valid CHECK ((action = ANY (ARRAY['add'::text, 'remove'::text]))),
    CONSTRAINT change_period_positive CHECK ((period_number >= 1)),
    CONSTRAINT change_scope_valid CHECK ((scope = ANY (ARRAY['from_here_on'::text, 'this_period_only'::text])))
);


--
-- Name: parameters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parameters (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    unit text,
    min_value numeric,
    max_value numeric,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT parameter_name_length CHECK (((char_length(btrim(name)) >= 1) AND (char_length(btrim(name)) <= 60))),
    CONSTRAINT parameter_range_order CHECK (((min_value IS NULL) OR (max_value IS NULL) OR (min_value <= max_value)))
);


--
-- Name: saved_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_views (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    config jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT saved_view_name_length CHECK (((char_length(btrim(name)) >= 1) AND (char_length(btrim(name)) <= 60)))
);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    filename text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.students (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    student_code text NOT NULL,
    full_name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT full_name_length CHECK (((char_length(btrim(full_name)) >= 2) AND (char_length(btrim(full_name)) <= 100))),
    CONSTRAINT student_code_format CHECK ((student_code ~ '^[2-9A-HJ-NP-Z]{8}$'::text))
);


--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_preferences (
    user_id uuid NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    full_name text NOT NULL,
    password_hash text NOT NULL,
    role text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    must_change_password boolean DEFAULT true NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT users_full_name_length CHECK (((char_length(btrim(full_name)) >= 1) AND (char_length(btrim(full_name)) <= 100))),
    CONSTRAINT users_role_valid CHECK ((role = ANY (ARRAY['viewer'::text, 'staff'::text, 'admin'::text]))),
    CONSTRAINT users_username_format CHECK ((username ~ '^[a-z0-9._-]{3,32}$'::text))
);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, occurred_at, user_id, actor, action, entity_type, entity_id, details) FROM stdin;
1	2026-09-21 01:30:10.260906+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
2	2026-09-21 01:30:10.289433+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.create	student	b36da6ba-aa44-4083-929c-0fb31c5b36cb	{"path": "/api/students", "method": "POST", "result": {"id": "b36da6ba-aa44-4083-929c-0fb31c5b36cb", "fullName": "Audit Test Student", "createdAt": {}, "studentCode": "KPJLZUTU"}, "request": {"fullName": "Audit Test Student"}}
3	2026-09-21 01:30:10.40929+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login_failed	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
4	2026-09-21 01:34:35.779601+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "admin"}
5	2026-09-21 01:35:19.911327+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.delete	student	fdd7d6dd-e9a6-44fd-affb-a96366b88e2a	{"path": "/api/students/fdd7d6dd-e9a6-44fd-affb-a96366b88e2a", "method": "DELETE", "result": null, "request": {}}
6	2026-09-21 01:35:25.027675+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.update	student	24ae584a-563a-47d0-bee7-faa20fe36cfc	{"path": "/api/students/24ae584a-563a-47d0-bee7-faa20fe36cfc", "method": "PATCH", "result": {"id": "24ae584a-563a-47d0-bee7-faa20fe36cfc", "fullName": "Mind Of", "createdAt": {}, "studentCode": "BH4UCBZ6"}, "request": {"fullName": "Mind Of"}}
7	2026-09-21 01:35:34.014799+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.create	student	1ada8d71-f3d8-499f-94dc-14b444a0152a	{"path": "/api/students", "method": "POST", "result": {"id": "1ada8d71-f3d8-499f-94dc-14b444a0152a", "fullName": "ff fff", "createdAt": {}, "studentCode": "JEMH6XF4"}, "request": {"fullName": "ff fff"}}
8	2026-09-21 01:35:55.006678+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	scores.save	period	9	{"count": 2, "changes": [{"to": 8, "from": null, "student": "ff fff", "parameter": "Speed", "studentId": "1ada8d71-f3d8-499f-94dc-14b444a0152a", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "JEMH6XF4"}, {"to": 2, "from": null, "student": "ff fff", "parameter": "Test Skill", "studentId": "1ada8d71-f3d8-499f-94dc-14b444a0152a", "parameterId": "d86df7c7-04c7-448b-b133-10b4756173e1", "studentCode": "JEMH6XF4"}], "periodNumber": 9}
9	2026-09-21 01:36:05.30979+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	parameter_change.create	parameter_change	e052af94-6e88-4adb-9744-fd36fc87686d	{"path": "/api/parameter-changes", "method": "POST", "result": {"id": "e052af94-6e88-4adb-9744-fd36fc87686d", "scope": "this_period_only", "action": "remove", "createdAt": {}, "parameterId": "d86df7c7-04c7-448b-b133-10b4756173e1", "periodNumber": 9}, "request": {"scope": "this_period_only", "action": "remove", "parameterId": "d86df7c7-04c7-448b-b133-10b4756173e1", "periodNumber": 9}}
10	2026-09-21 01:36:12.712815+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	parameter.update	parameter	d86df7c7-04c7-448b-b133-10b4756173e1	{"path": "/api/parameters/d86df7c7-04c7-448b-b133-10b4756173e1", "method": "PATCH", "result": {"id": "d86df7c7-04c7-448b-b133-10b4756173e1", "name": "Test Skill", "unit": "verbals", "maxValue": 10, "minValue": 0, "sortOrder": 4}, "request": {"name": "Test Skill", "unit": "verbals", "maxValue": 10, "minValue": 0}}
11	2026-09-21 01:38:20.995954+03:30	\N	viewer1	auth.login_failed	user	\N	{"ip": "::1", "attemptedUsername": "viewer1"}
12	2026-09-21 01:38:32.951817+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.logout	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::ffff:127.0.0.1"}
13	2026-09-21 01:39:14.367216+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.login	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "viewer1"}
14	2026-09-21 01:39:58.996316+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.password_change	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::ffff:127.0.0.1"}
15	2026-09-21 01:40:05.686232+03:30	\N	viewer1	auth.login_failed	user	\N	{"ip": "::1", "attemptedUsername": "viewer1"}
16	2026-09-21 01:40:34.747354+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.login	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::1", "attemptedUsername": "viewer1"}
17	2026-09-21 01:41:07.25264+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.login	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::1", "attemptedUsername": "viewer1"}
18	2026-09-21 01:42:26.233885+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.logout	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::ffff:127.0.0.1"}
19	2026-09-21 01:42:40.450011+03:30	\N	staff1	auth.login_failed	user	\N	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "staff1"}
20	2026-09-21 01:43:13.833346+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.login	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "staff1"}
21	2026-09-21 01:43:44.524186+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.password_change	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::ffff:127.0.0.1"}
22	2026-09-21 01:43:54.813186+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	scores.save	period	9	{"count": 1, "changes": [{"to": 2, "from": null, "student": "ff fff", "parameter": "Balance", "studentId": "1ada8d71-f3d8-499f-94dc-14b444a0152a", "parameterId": "abd98cd1-f901-4fdd-8033-e31918f28156", "studentCode": "JEMH6XF4"}], "periodNumber": 9}
23	2026-09-21 01:44:01.357644+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.logout	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::ffff:127.0.0.1"}
24	2026-09-21 01:44:21.116327+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "admin"}
25	2026-09-21 03:58:27.575755+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.delete	student	b36da6ba-aa44-4083-929c-0fb31c5b36cb	{"path": "/api/students/b36da6ba-aa44-4083-929c-0fb31c5b36cb", "method": "DELETE", "result": null, "request": {}}
26	2026-09-21 17:06:11.633878+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
27	2026-09-21 17:06:11.674816+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	user.create	user	38f8b39c-d3ed-406a-af9b-173179079f28	{"role": "staff", "fullName": "Tina Teacher", "username": "teacher1"}
28	2026-09-21 17:07:43.088893+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
29	2026-09-21 17:07:55.667119+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
30	2026-09-21 17:09:41.726406+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.login	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::1", "attemptedUsername": "viewer1"}
31	2026-09-21 17:10:37.233123+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.login	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::1", "attemptedUsername": "viewer1"}
32	2026-09-21 17:13:52.698878+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.login	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::1", "attemptedUsername": "viewer1"}
33	2026-09-21 17:16:28.025395+03:30	\N	viewer1	auth.login_failed	user	\N	{"ip": "::1", "attemptedUsername": "viewer1"}
34	2026-09-21 17:16:43.749953+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.login	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::1", "attemptedUsername": "staff1"}
35	2026-09-21 17:16:54.051918+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.login	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::1", "attemptedUsername": "staff1"}
36	2026-09-21 17:23:19.903864+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	user.create	user	70565337-2fea-47a1-8aed-ae270f79a594	{"role": "staff", "fullName": "TOmas STaff", "username": "teacher2"}
37	2026-09-21 17:24:38.751993+03:30	70565337-2fea-47a1-8aed-ae270f79a594	teacher2	auth.login	user	70565337-2fea-47a1-8aed-ae270f79a594	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "teacher2"}
38	2026-09-21 17:24:56.305412+03:30	70565337-2fea-47a1-8aed-ae270f79a594	teacher2	auth.password_change	user	70565337-2fea-47a1-8aed-ae270f79a594	{"ip": "::ffff:127.0.0.1"}
39	2026-09-21 17:25:23.292053+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	user.update	user	70565337-2fea-47a1-8aed-ae270f79a594	{"changes": {"role": {"to": "viewer", "from": "staff"}}, "username": "teacher2"}
40	2026-09-21 17:25:38.97198+03:30	70565337-2fea-47a1-8aed-ae270f79a594	teacher2	auth.logout	user	70565337-2fea-47a1-8aed-ae270f79a594	{"ip": "::ffff:127.0.0.1"}
41	2026-09-21 17:25:48.129907+03:30	70565337-2fea-47a1-8aed-ae270f79a594	teacher2	auth.login	user	70565337-2fea-47a1-8aed-ae270f79a594	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "teacher2"}
42	2026-09-21 17:26:12.143391+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	user.update	user	70565337-2fea-47a1-8aed-ae270f79a594	{"changes": {"role": {"to": "staff", "from": "viewer"}}, "username": "teacher2"}
43	2026-09-21 17:30:38.977451+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	user.update	user	70565337-2fea-47a1-8aed-ae270f79a594	{"changes": {"isActive": {"to": false, "from": true}}, "username": "teacher2"}
44	2026-09-21 17:30:55.652299+03:30	\N	teacher2	auth.login_failed	user	\N	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "teacher2"}
45	2026-09-21 17:30:57.491389+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	user.update	user	70565337-2fea-47a1-8aed-ae270f79a594	{"changes": {"isActive": {"to": true, "from": false}}, "username": "teacher2"}
46	2026-09-21 17:30:59.965012+03:30	70565337-2fea-47a1-8aed-ae270f79a594	teacher2	auth.login	user	70565337-2fea-47a1-8aed-ae270f79a594	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "teacher2"}
47	2026-09-21 17:31:14.243368+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	user.password_reset	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"username": "viewer1"}
48	2026-09-21 17:31:36.279106+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	user.password_reset	user	70565337-2fea-47a1-8aed-ae270f79a594	{"username": "teacher2"}
49	2026-09-21 17:31:49.555593+03:30	\N	teacher2	auth.login_failed	user	\N	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "teacher2"}
50	2026-09-21 17:32:29.369479+03:30	\N	teacher2	auth.login_failed	user	\N	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "teacher2"}
51	2026-09-21 17:32:37.420641+03:30	70565337-2fea-47a1-8aed-ae270f79a594	teacher2	auth.login	user	70565337-2fea-47a1-8aed-ae270f79a594	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "teacher2"}
52	2026-09-21 17:32:51.729114+03:30	70565337-2fea-47a1-8aed-ae270f79a594	teacher2	auth.password_change	user	70565337-2fea-47a1-8aed-ae270f79a594	{"ip": "::ffff:127.0.0.1"}
53	2026-09-21 17:37:03.289489+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
54	2026-09-21 17:37:23.967157+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.login	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::1", "attemptedUsername": "staff1"}
55	2026-09-21 17:38:24.801005+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	scores.save	period	9	{"count": 1, "changes": [{"to": 5, "from": null, "student": "Mind Of", "override": false, "parameter": "Speed", "studentId": "24ae584a-563a-47d0-bee7-faa20fe36cfc", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "BH4UCBZ6"}], "periodNumber": 9}
56	2026-09-21 17:38:33.686451+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	scores.save	period	7	{"count": 1, "changes": [{"to": 6, "from": null, "student": "Mind Of", "override": false, "parameter": "Speed", "studentId": "24ae584a-563a-47d0-bee7-faa20fe36cfc", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "BH4UCBZ6"}], "periodNumber": 7}
57	2026-09-21 17:40:27.764624+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	scores.save	period	9	{"count": 1, "changes": [{"to": 9, "from": 5, "student": "Mind Of", "override": true, "parameter": "Speed", "studentId": "24ae584a-563a-47d0-bee7-faa20fe36cfc", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "BH4UCBZ6"}], "periodNumber": 9, "overrideReason": "Typo corrected after teacher review"}
58	2026-09-21 17:41:55.36388+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	scores.save	period	9	{"count": 1, "changes": [{"to": null, "from": 9, "student": "Mind Of", "override": true, "parameter": "Speed", "studentId": "24ae584a-563a-47d0-bee7-faa20fe36cfc", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "BH4UCBZ6"}], "periodNumber": 9, "overrideReason": "Entered for the wrong student"}
59	2026-09-21 17:49:58.773929+03:30	70565337-2fea-47a1-8aed-ae270f79a594	teacher2	auth.logout	user	70565337-2fea-47a1-8aed-ae270f79a594	{"ip": "::ffff:127.0.0.1"}
60	2026-09-21 17:50:04.439021+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.login	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "staff1"}
61	2026-09-21 17:51:08.951268+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	scores.save	period	7	{"count": 1, "changes": [{"to": 1, "from": null, "student": "Mind Of", "override": false, "parameter": "Rhythm", "studentId": "24ae584a-563a-47d0-bee7-faa20fe36cfc", "parameterId": "f482a4c1-4877-4041-b2f8-13ceb7a40323", "studentCode": "BH4UCBZ6"}], "periodNumber": 7}
62	2026-09-21 17:51:19.759205+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	scores.save	period	9	{"count": 1, "changes": [{"to": 1, "from": null, "student": "Mind Of", "override": false, "parameter": "Rhythm", "studentId": "24ae584a-563a-47d0-bee7-faa20fe36cfc", "parameterId": "f482a4c1-4877-4041-b2f8-13ceb7a40323", "studentCode": "BH4UCBZ6"}], "periodNumber": 9}
63	2026-09-21 17:52:31.310506+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	scores.save	period	9	{"count": 1, "changes": [{"to": 7, "from": null, "student": "Mind Of", "override": true, "parameter": "Speed", "studentId": "24ae584a-563a-47d0-bee7-faa20fe36cfc", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "BH4UCBZ6"}], "periodNumber": 9, "overrideReason": "to test"}
64	2026-09-21 17:53:33.25774+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	scores.save	period	9	{"count": 1, "changes": [{"to": null, "from": 7, "student": "Mind Of", "override": true, "parameter": "Speed", "studentId": "24ae584a-563a-47d0-bee7-faa20fe36cfc", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "BH4UCBZ6"}], "periodNumber": 9, "overrideReason": "to test again"}
65	2026-09-21 17:54:41.706349+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	scores.save	period	9	{"count": 2, "changes": [{"to": 1, "from": null, "student": "Mind Of", "override": true, "parameter": "Speed", "studentId": "24ae584a-563a-47d0-bee7-faa20fe36cfc", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "BH4UCBZ6"}, {"to": 1, "from": null, "student": "ff fff", "override": false, "parameter": "Rhythm", "studentId": "1ada8d71-f3d8-499f-94dc-14b444a0152a", "parameterId": "f482a4c1-4877-4041-b2f8-13ceb7a40323", "studentCode": "JEMH6XF4"}], "periodNumber": 9, "overrideReason": "yrp tep"}
66	2026-09-21 17:55:05.360579+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	scores.save	period	9	{"count": 3, "changes": [{"to": 1, "from": null, "student": "Ana Rousi", "override": false, "parameter": "Rhythm", "studentId": "0af19126-b42f-44f4-9c03-e7b645259ba3", "parameterId": "f482a4c1-4877-4041-b2f8-13ceb7a40323", "studentCode": "JFPRYAGJ"}, {"to": 1, "from": null, "student": "Ana Rousi", "override": false, "parameter": "Balance", "studentId": "0af19126-b42f-44f4-9c03-e7b645259ba3", "parameterId": "abd98cd1-f901-4fdd-8033-e31918f28156", "studentCode": "JFPRYAGJ"}, {"to": 8, "from": 4, "student": "Maria Lopez", "override": false, "parameter": "Balance", "studentId": "cc47388b-00aa-4d59-a46e-446f4eb7452d", "parameterId": "abd98cd1-f901-4fdd-8033-e31918f28156", "studentCode": "M8CMQS6A"}], "periodNumber": 9}
67	2026-09-21 18:01:46.040648+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
68	2026-09-21 18:02:25.326474+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
69	2026-09-21 18:02:28.684038+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
70	2026-09-21 18:03:54.31042+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
71	2026-09-21 18:04:26.568576+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
72	2026-09-21 18:04:56.544817+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
73	2026-09-21 18:23:40.156344+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
74	2026-09-21 18:24:41.243567+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
75	2026-09-21 18:25:55.319566+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
76	2026-09-21 18:26:26.917474+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
77	2026-09-21 18:26:34.672215+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
78	2026-09-21 18:27:06.634323+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
79	2026-09-21 18:28:04.513476+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
80	2026-09-21 18:29:57.170422+03:30	\N	viewer1	auth.login_failed	user	\N	{"ip": "::1", "attemptedUsername": "viewer1"}
81	2026-09-21 18:30:23.123665+03:30	\N	viewer1	auth.login_failed	user	\N	{"ip": "::1", "attemptedUsername": "viewer1"}
82	2026-09-21 18:30:48.887478+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
83	2026-09-21 18:34:19.43961+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
84	2026-09-21 18:34:37.374667+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
85	2026-09-21 18:34:39.903936+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
86	2026-09-21 18:34:57.954528+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.logout	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::ffff:127.0.0.1"}
87	2026-09-21 18:35:27.207478+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
88	2026-09-21 23:44:22.523007+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
89	2026-09-21 23:45:27.024225+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
90	2026-09-21 23:51:33.151774+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
91	2026-09-22 00:03:29.216714+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
92	2026-09-22 00:03:57.786585+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
93	2026-09-22 00:04:27.395102+03:30	\N	viewer1	auth.login_failed	user	\N	{"ip": "::1", "attemptedUsername": "viewer1"}
94	2026-09-22 04:50:25.482366+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
95	2026-09-22 04:59:10.719104+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
96	2026-09-22 04:59:54.736359+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
97	2026-09-22 05:01:05.328958+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
98	2026-09-22 05:01:35.791456+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.import	student	\N	{"count": 1, "skipped": 0, "students": [{"fullName": "Nadia Kowalski", "studentCode": "YM3S5AQ4"}], "moreStudents": 0, "allowDuplicateNames": false}
99	2026-09-22 05:01:35.835949+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.import	student	\N	{"count": 1, "skipped": 0, "students": [{"fullName": "Nadia Kowalski", "studentCode": "2EM9KGER"}], "moreStudents": 0, "allowDuplicateNames": true}
100	2026-09-22 05:01:42.585254+03:30	\N	viewer1	auth.login_failed	user	\N	{"ip": "::1", "attemptedUsername": "viewer1"}
101	2026-09-22 05:02:09.428744+03:30	\N	viewer1	auth.login_failed	user	\N	{"ip": "::1", "attemptedUsername": "viewer1"}
102	2026-09-22 05:14:44.065747+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.import	student	\N	{"count": 4, "skipped": 4, "students": [{"fullName": "João Silva", "studentCode": "4HVRRYP3"}, {"fullName": "O'Brien, Pat Jr", "studentCode": "M76M3X6V"}, {"fullName": "=HYPERLINK(\\"http://example.com\\") Test", "studentCode": "2H9PTKFP"}, {"fullName": "Zoë Müller", "studentCode": "QSZCABLG"}], "moreStudents": 0, "allowDuplicateNames": false}
103	2026-09-22 05:15:47.499002+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.import	student	\N	{"count": 7, "skipped": 1, "students": [{"fullName": "Maria Lopez", "studentCode": "AQ6ZKAQD"}, {"fullName": "João Silva", "studentCode": "7LYH3QDS"}, {"fullName": "Ana Souza", "studentCode": "RS7KLGC6"}, {"fullName": "Ana Souza", "studentCode": "5XSBBX92"}, {"fullName": "O'Brien, Pat Jr", "studentCode": "XWYZRTEH"}, {"fullName": "=HYPERLINK(\\"http://example.com\\") Test", "studentCode": "RDM9HX4H"}, {"fullName": "Zoë Müller", "studentCode": "N2YZPB99"}], "moreStudents": 0, "allowDuplicateNames": true}
104	2026-09-22 05:16:16.129151+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.import	student	\N	{"count": 7, "skipped": 1, "students": [{"fullName": "Maria Lopez", "studentCode": "2ATLUWYP"}, {"fullName": "João Silva", "studentCode": "FL2VYFXT"}, {"fullName": "Ana Souza", "studentCode": "FK7PD5BQ"}, {"fullName": "Ana Souza", "studentCode": "TCBPFT6K"}, {"fullName": "O'Brien, Pat Jr", "studentCode": "Q4EV79VX"}, {"fullName": "=HYPERLINK(\\"http://example.com\\") Test", "studentCode": "UFPFXL8H"}, {"fullName": "Zoë Müller", "studentCode": "LYVXHJ8E"}], "moreStudents": 0, "allowDuplicateNames": true}
105	2026-09-22 05:22:26.607576+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::1", "attemptedUsername": "admin"}
106	2026-09-22 05:23:56.484791+03:30	\N	viewer1	auth.login_failed	user	\N	{"ip": "::1", "attemptedUsername": "viewer1"}
107	2026-09-22 05:51:30.159869+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	scores.save	period	9	{"count": 17, "source": "import", "changes": [{"to": 3, "from": null, "student": "Ana Rousi", "override": false, "parameter": "Speed", "studentId": "0af19126-b42f-44f4-9c03-e7b645259ba3", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "JFPRYAGJ"}, {"to": 2, "from": 1, "student": "Ana Rousi", "override": false, "parameter": "Balance", "studentId": "0af19126-b42f-44f4-9c03-e7b645259ba3", "parameterId": "abd98cd1-f901-4fdd-8033-e31918f28156", "studentCode": "JFPRYAGJ"}, {"to": 6, "from": null, "student": "Ana Souza", "override": false, "parameter": "Speed", "studentId": "25d9f9ff-8c6a-4b1b-8892-fbc44677d1d8", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "FK7PD5BQ"}, {"to": 4, "from": null, "student": "Ana Souza", "override": false, "parameter": "Balance", "studentId": "25d9f9ff-8c6a-4b1b-8892-fbc44677d1d8", "parameterId": "abd98cd1-f901-4fdd-8033-e31918f28156", "studentCode": "FK7PD5BQ"}, {"to": 9, "from": null, "student": "Ana Souza", "override": false, "parameter": "Speed", "studentId": "8f938431-6a22-4fa9-8fcd-b0bfee19d5ae", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "TCBPFT6K"}, {"to": 6, "from": null, "student": "Ana Souza", "override": false, "parameter": "Balance", "studentId": "8f938431-6a22-4fa9-8fcd-b0bfee19d5ae", "parameterId": "abd98cd1-f901-4fdd-8033-e31918f28156", "studentCode": "TCBPFT6K"}, {"to": 1, "from": null, "student": "Ana Souza", "override": false, "parameter": "Speed", "studentId": "fe2f0d66-c34e-4549-a690-a09caa05653b", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "5XSBBX92"}, {"to": 8, "from": null, "student": "Ana Souza", "override": false, "parameter": "Balance", "studentId": "fe2f0d66-c34e-4549-a690-a09caa05653b", "parameterId": "abd98cd1-f901-4fdd-8033-e31918f28156", "studentCode": "5XSBBX92"}, {"to": 4, "from": null, "student": "Ana Souza", "override": false, "parameter": "Speed", "studentId": "ce7deec6-1bcb-4af1-87b2-4b2b58ae7a99", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "CFJS4PLC"}, {"to": 1, "from": null, "student": "Ana Souza", "override": false, "parameter": "Balance", "studentId": "ce7deec6-1bcb-4af1-87b2-4b2b58ae7a99", "parameterId": "abd98cd1-f901-4fdd-8033-e31918f28156", "studentCode": "CFJS4PLC"}, {"to": 7, "from": null, "student": "Ana Souza", "override": false, "parameter": "Speed", "studentId": "3576a8bb-9fd9-438b-8f88-91298f2f7754", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "RS7KLGC6"}, {"to": 3, "from": null, "student": "Ana Souza", "override": false, "parameter": "Balance", "studentId": "3576a8bb-9fd9-438b-8f88-91298f2f7754", "parameterId": "abd98cd1-f901-4fdd-8033-e31918f28156", "studentCode": "RS7KLGC6"}, {"to": 10, "from": 8, "student": "ff fff", "override": false, "parameter": "Speed", "studentId": "1ada8d71-f3d8-499f-94dc-14b444a0152a", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "JEMH6XF4"}, {"to": 5, "from": 2, "student": "ff fff", "override": false, "parameter": "Balance", "studentId": "1ada8d71-f3d8-499f-94dc-14b444a0152a", "parameterId": "abd98cd1-f901-4fdd-8033-e31918f28156", "studentCode": "JEMH6XF4"}, {"to": 2, "from": null, "student": "=HYPERLINK(\\"http://example.com\\") Test", "override": false, "parameter": "Speed", "studentId": "39b1bfd0-5db8-44db-a41e-9f859ac67510", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "2H9PTKFP"}, {"to": 0, "from": null, "student": "=HYPERLINK(\\"http://example.com\\") Test", "override": false, "parameter": "Balance", "studentId": "001b06a9-dccb-4065-bc46-2e47752922c6", "parameterId": "abd98cd1-f901-4fdd-8033-e31918f28156", "studentCode": "RDM9HX4H"}, {"to": 8, "from": null, "student": "=HYPERLINK(\\"http://example.com\\") Test", "override": false, "parameter": "Speed", "studentId": "d9e99ecd-ce8d-47a7-8453-fee350975696", "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "studentCode": "UFPFXL8H"}], "periodNumber": 9}
108	2026-09-22 06:01:17.727348+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	user.password_reset	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"username": "viewer1"}
109	2026-09-22 06:01:20.335603+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.logout	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::ffff:127.0.0.1"}
110	2026-09-22 06:01:25.201445+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.login	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "viewer1"}
111	2026-09-22 06:01:37.37097+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.password_change	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::ffff:127.0.0.1"}
112	2026-09-22 06:02:37.188557+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "admin"}
113	2026-09-22 06:02:37.384178+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.login	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "staff1"}
114	2026-09-22 06:02:37.54115+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.login	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "viewer1"}
115	2026-09-22 06:02:37.665861+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.create	student	694bbf06-9389-43c6-a71b-22a9f5c0bf8c	{"path": "/api/students", "method": "POST", "result": {"id": "694bbf06-9389-43c6-a71b-22a9f5c0bf8c", "fullName": "Permission Test", "createdAt": {}, "studentCode": "GFMJNB7T"}, "request": {"fullName": "Permission Test"}}
116	2026-09-22 06:02:37.708258+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	parameter.create	parameter	006628be-1f2b-4a93-addb-59e2624b9da2	{"path": "/api/parameters", "method": "POST", "result": {"id": "006628be-1f2b-4a93-addb-59e2624b9da2", "name": "x", "unit": null, "maxValue": null, "minValue": null, "sortOrder": 6}, "request": {"name": "x", "startPeriod": 1}}
117	2026-09-22 06:03:16.05961+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.logout	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::ffff:127.0.0.1"}
118	2026-09-22 06:03:27.918274+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.login	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "staff1"}
119	2026-09-22 06:04:15.479459+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "admin"}
120	2026-09-22 06:04:15.662678+03:30	\N	staff1	auth.login_failed	user	\N	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "staff1"}
121	2026-09-22 06:04:50.235287+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "admin"}
122	2026-09-22 06:04:50.421089+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.login	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "staff1"}
123	2026-09-22 06:04:50.578875+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.login	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "viewer1"}
124	2026-09-22 06:04:50.706338+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.create	student	8fda872c-6912-4e38-bab2-d00c74bb9543	{"path": "/api/students", "method": "POST", "result": {"id": "8fda872c-6912-4e38-bab2-d00c74bb9543", "fullName": "Permission Test", "createdAt": {}, "studentCode": "5A9J63T6"}, "request": {"fullName": "Permission Test"}}
125	2026-09-22 06:09:09.866475+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "admin"}
126	2026-09-22 06:09:10.06326+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.login	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "staff1"}
127	2026-09-22 06:09:10.240743+03:30	6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	auth.login	user	6244afeb-a488-475a-92e8-d5b792b9cec4	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "viewer1"}
128	2026-09-22 06:09:10.559421+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.create	student	52464aec-a67d-445a-aa64-759df991295c	{"path": "/api/students", "method": "POST", "result": {"id": "52464aec-a67d-445a-aa64-759df991295c", "fullName": "Permission Test", "createdAt": {}, "studentCode": "37ZMBKK7"}, "request": {"fullName": "Permission Test"}}
129	2026-09-22 06:16:47.643109+03:30	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	auth.logout	user	0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	{"ip": "::ffff:127.0.0.1"}
130	2026-09-22 06:17:27.055396+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	auth.login	user	05fd9481-3ecb-4926-a04e-ba254699da4e	{"ip": "::ffff:127.0.0.1", "attemptedUsername": "admin"}
131	2026-09-22 06:18:43.76531+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.create	student	4e8a2c57-c48e-4a79-970c-efc402f55e08	{"path": "/api/students", "method": "POST", "result": {"id": "4e8a2c57-c48e-4a79-970c-efc402f55e08", "fullName": "Test Walkthrough One", "createdAt": {}, "studentCode": "7ZQJUTPH"}, "request": {"fullName": "Test Walkthrough One"}}
132	2026-09-22 06:18:57.877169+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.create	student	a168a2ff-75aa-48f0-bdf8-a12fa6af32fa	{"path": "/api/students", "method": "POST", "result": {"id": "a168a2ff-75aa-48f0-bdf8-a12fa6af32fa", "fullName": "Test Walkthrough One", "createdAt": {}, "studentCode": "2DT8L9UH"}, "request": {"fullName": "Test Walkthrough One"}}
133	2026-09-22 06:19:25.260784+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.update	student	4e8a2c57-c48e-4a79-970c-efc402f55e08	{"path": "/api/students/4e8a2c57-c48e-4a79-970c-efc402f55e08", "method": "PATCH", "result": {"id": "4e8a2c57-c48e-4a79-970c-efc402f55e08", "fullName": "Test Walkthrough One1", "createdAt": {}, "studentCode": "7ZQJUTPH"}, "request": {"fullName": "Test Walkthrough One1"}}
134	2026-09-22 06:19:27.644114+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	student.delete	student	a168a2ff-75aa-48f0-bdf8-a12fa6af32fa	{"path": "/api/students/a168a2ff-75aa-48f0-bdf8-a12fa6af32fa", "method": "DELETE", "result": null, "request": {}}
135	2026-09-22 06:20:35.241993+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	scores.save	period	9	{"count": 1, "changes": [{"to": 1, "from": null, "student": "Test Walkthrough One1", "override": false, "parameter": "Rhythm", "studentId": "4e8a2c57-c48e-4a79-970c-efc402f55e08", "parameterId": "f482a4c1-4877-4041-b2f8-13ceb7a40323", "studentCode": "7ZQJUTPH"}], "periodNumber": 9}
136	2026-09-22 06:20:48.930877+03:30	05fd9481-3ecb-4926-a04e-ba254699da4e	admin	scores.save	period	8	{"count": 1, "changes": [{"to": 3, "from": null, "student": "Permission Test", "override": false, "parameter": "Rhythm", "studentId": "8fda872c-6912-4e38-bab2-d00c74bb9543", "parameterId": "f482a4c1-4877-4041-b2f8-13ceb7a40323", "studentCode": "5A9J63T6"}], "periodNumber": 8}
\.


--
-- Data for Name: evaluations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.evaluations (id, student_id, parameter_id, period_number, value, created_at, updated_at, locks_at) FROM stdin;
c2397b8e-1520-427d-be0f-7598e492bf1d	4e8a2c57-c48e-4a79-970c-efc402f55e08	f482a4c1-4877-4041-b2f8-13ceb7a40323	9	1	2026-09-22 06:20:35.241993+03:30	2026-09-22 06:20:35.241993+03:30	2026-09-29 06:20:35.241993+03:30
5bf38be0-f87e-4965-8684-48d7453c9f43	8fda872c-6912-4e38-bab2-d00c74bb9543	f482a4c1-4877-4041-b2f8-13ceb7a40323	8	3	2026-09-22 06:20:48.930877+03:30	2026-09-22 06:20:48.930877+03:30	2026-09-23 06:20:48.930877+03:30
34117702-0d45-4ae6-a83f-430ab4d48a11	24ae584a-563a-47d0-bee7-faa20fe36cfc	279a4c76-7b0d-4504-b0a8-c6f2d667afee	9	1	2026-09-21 17:38:24.801005+03:30	2026-09-21 17:54:41.706349+03:30	2026-09-29 05:54:02.411411+03:30
bd840a1c-d4a0-4c86-86ee-247c2589c7c7	0af19126-b42f-44f4-9c03-e7b645259ba3	abd98cd1-f901-4fdd-8033-e31918f28156	9	2	2026-09-21 17:55:05.360579+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-28 17:55:05.360579+03:30
f2e73f7d-fcf5-42f0-89bb-439b86dbb4dc	0af19126-b42f-44f4-9c03-e7b645259ba3	279a4c76-7b0d-4504-b0a8-c6f2d667afee	9	3	2026-09-20 22:00:06.324291+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:54:02.411411+03:30
a66a50aa-6166-42e2-b156-f069e02e0c21	cc47388b-00aa-4d59-a46e-446f4eb7452d	279a4c76-7b0d-4504-b0a8-c6f2d667afee	8	9	2026-09-20 21:59:43.119178+03:30	2026-09-20 21:59:43.119178+03:30	2026-09-27 21:59:43.119178+03:30
74b6a6db-16f1-4f14-9ac0-deb1f42a2d03	0af19126-b42f-44f4-9c03-e7b645259ba3	279a4c76-7b0d-4504-b0a8-c6f2d667afee	7	4	2026-09-20 21:59:52.12565+03:30	2026-09-20 21:59:52.12565+03:30	2026-09-27 21:59:52.12565+03:30
155e8b25-0c39-4d2a-9756-04d0c37e02cb	1ada8d71-f3d8-499f-94dc-14b444a0152a	279a4c76-7b0d-4504-b0a8-c6f2d667afee	9	10	2026-09-21 01:35:55.006678+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:54:02.411411+03:30
36344b32-00ee-40ef-a332-d6182a843b75	0af19126-b42f-44f4-9c03-e7b645259ba3	279a4c76-7b0d-4504-b0a8-c6f2d667afee	4	7	2026-09-20 22:03:12.176327+03:30	2026-09-20 22:03:12.176327+03:30	2026-09-27 22:03:12.176327+03:30
6b7ed678-7905-44cf-a2d2-ea343d3b9608	0af19126-b42f-44f4-9c03-e7b645259ba3	f482a4c1-4877-4041-b2f8-13ceb7a40323	4	9	2026-09-20 22:03:12.176327+03:30	2026-09-20 22:03:12.176327+03:30	2026-09-27 22:03:12.176327+03:30
570ada45-0517-47c6-8332-10664a9943a8	cc47388b-00aa-4d59-a46e-446f4eb7452d	d86df7c7-04c7-448b-b133-10b4756173e1	8	8	2026-09-20 22:14:20.042244+03:30	2026-09-20 22:14:20.042244+03:30	2026-09-27 22:14:20.042244+03:30
d056647f-9df8-4ef8-a738-64cb1087e620	ce7deec6-1bcb-4af1-87b2-4b2b58ae7a99	d86df7c7-04c7-448b-b133-10b4756173e1	8	4	2026-09-20 22:14:20.042244+03:30	2026-09-20 22:14:20.042244+03:30	2026-09-27 22:14:20.042244+03:30
aab2f51b-6f49-41ac-8a29-b2459cbb0ce8	24ae584a-563a-47d0-bee7-faa20fe36cfc	279a4c76-7b0d-4504-b0a8-c6f2d667afee	3	7	2026-09-20 22:38:05.365979+03:30	2026-09-20 22:38:05.365979+03:30	2026-09-27 22:38:05.365979+03:30
a015b396-e10b-4301-951f-4639013e26ac	24ae584a-563a-47d0-bee7-faa20fe36cfc	279a4c76-7b0d-4504-b0a8-c6f2d667afee	4	8	2026-09-20 22:38:05.396901+03:30	2026-09-20 22:38:05.396901+03:30	2026-09-27 22:38:05.396901+03:30
bb2870a3-1188-485d-828c-262f4dab2800	24ae584a-563a-47d0-bee7-faa20fe36cfc	279a4c76-7b0d-4504-b0a8-c6f2d667afee	6	5	2026-09-20 22:38:05.419148+03:30	2026-09-20 22:38:05.419148+03:30	2026-09-27 22:38:05.419148+03:30
220a7f84-f2aa-4071-a3ba-60dabcad9f3e	1ada8d71-f3d8-499f-94dc-14b444a0152a	f482a4c1-4877-4041-b2f8-13ceb7a40323	9	1	2026-09-21 17:54:41.706349+03:30	2026-09-21 17:54:41.706349+03:30	2026-09-28 17:54:41.706349+03:30
882cf6e5-8c7d-44ad-a495-ccec77588366	24ae584a-563a-47d0-bee7-faa20fe36cfc	279a4c76-7b0d-4504-b0a8-c6f2d667afee	8	7	2026-09-20 22:38:05.458057+03:30	2026-09-20 22:38:05.458057+03:30	2026-09-27 22:38:05.458057+03:30
fee56797-d9bc-4ed8-9dbe-c81345598c71	0af19126-b42f-44f4-9c03-e7b645259ba3	f482a4c1-4877-4041-b2f8-13ceb7a40323	9	1	2026-09-21 17:55:05.360579+03:30	2026-09-21 17:55:05.360579+03:30	2026-09-28 17:55:05.360579+03:30
4823e1b8-6a62-4527-8ace-0d062b7838fa	24ae584a-563a-47d0-bee7-faa20fe36cfc	f482a4c1-4877-4041-b2f8-13ceb7a40323	3	6	2026-09-20 22:38:05.497419+03:30	2026-09-20 22:38:05.497419+03:30	2026-09-27 22:38:05.497419+03:30
1814de82-dac8-4c97-a542-e007ae71074f	24ae584a-563a-47d0-bee7-faa20fe36cfc	f482a4c1-4877-4041-b2f8-13ceb7a40323	4	3	2026-09-20 22:38:05.51514+03:30	2026-09-20 22:38:05.51514+03:30	2026-09-27 22:38:05.51514+03:30
154ebcaf-d640-450e-8f39-f31654d54e1a	24ae584a-563a-47d0-bee7-faa20fe36cfc	f482a4c1-4877-4041-b2f8-13ceb7a40323	5	4	2026-09-20 22:38:05.534932+03:30	2026-09-20 22:38:05.534932+03:30	2026-09-27 22:38:05.534932+03:30
a9288d7c-5a37-4414-b09a-d48d59a92faf	24ae584a-563a-47d0-bee7-faa20fe36cfc	f482a4c1-4877-4041-b2f8-13ceb7a40323	6	5	2026-09-20 22:38:05.554461+03:30	2026-09-20 22:38:05.554461+03:30	2026-09-27 22:38:05.554461+03:30
6bf87c14-a12b-4bba-a9bd-5ecc6587336d	24ae584a-563a-47d0-bee7-faa20fe36cfc	f482a4c1-4877-4041-b2f8-13ceb7a40323	8	3	2026-09-20 22:38:05.591123+03:30	2026-09-20 22:38:05.591123+03:30	2026-09-27 22:38:05.591123+03:30
cc12dd72-1d0e-42ca-90b8-c6279af3b398	cc47388b-00aa-4d59-a46e-446f4eb7452d	abd98cd1-f901-4fdd-8033-e31918f28156	9	8	2026-09-20 22:00:06.324291+03:30	2026-09-21 17:55:05.360579+03:30	2026-09-27 22:00:06.324291+03:30
48bef4b6-e803-41ad-8974-a9535a835e27	24ae584a-563a-47d0-bee7-faa20fe36cfc	abd98cd1-f901-4fdd-8033-e31918f28156	6	5	2026-09-20 22:38:05.630016+03:30	2026-09-20 22:38:05.630016+03:30	2026-09-27 22:38:05.630016+03:30
a9886921-2040-4b60-9244-ad41047070f5	24ae584a-563a-47d0-bee7-faa20fe36cfc	abd98cd1-f901-4fdd-8033-e31918f28156	8	7	2026-09-20 22:38:05.667434+03:30	2026-09-20 22:38:05.667434+03:30	2026-09-27 22:38:05.667434+03:30
8cc13f9c-e7d7-423f-93e3-1819d4fc5cb9	1ada8d71-f3d8-499f-94dc-14b444a0152a	d86df7c7-04c7-448b-b133-10b4756173e1	9	2	2026-09-21 01:35:55.006678+03:30	2026-09-21 01:35:55.006678+03:30	2026-09-28 01:35:55.006678+03:30
e55b2c92-d0a5-4d18-b526-d2df8769045d	24ae584a-563a-47d0-bee7-faa20fe36cfc	279a4c76-7b0d-4504-b0a8-c6f2d667afee	7	6	2026-09-21 17:38:33.686451+03:30	2026-09-21 17:38:33.686451+03:30	2026-09-21 17:38:35.58366+03:30
a77b63f8-a3f3-4d12-8e46-9de8159a847a	1ada8d71-f3d8-499f-94dc-14b444a0152a	abd98cd1-f901-4fdd-8033-e31918f28156	9	5	2026-09-21 01:43:54.813186+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-28 01:43:54.813186+03:30
0ee51603-8c14-41f0-a4e7-485a8860a300	24ae584a-563a-47d0-bee7-faa20fe36cfc	f482a4c1-4877-4041-b2f8-13ceb7a40323	7	1	2026-09-21 17:51:08.951268+03:30	2026-09-21 17:51:08.951268+03:30	2026-09-22 17:51:08.951268+03:30
fcbba246-1f41-45da-beb2-9a5993ef40e6	24ae584a-563a-47d0-bee7-faa20fe36cfc	f482a4c1-4877-4041-b2f8-13ceb7a40323	9	1	2026-09-21 17:51:19.759205+03:30	2026-09-21 17:51:19.759205+03:30	2026-09-28 17:51:19.759205+03:30
c0f76993-c3ad-480e-a60f-6d06e85ac993	25d9f9ff-8c6a-4b1b-8892-fbc44677d1d8	abd98cd1-f901-4fdd-8033-e31918f28156	9	4	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:51:30.159869+03:30
b9706ede-7438-4dde-a816-8ed789c052aa	8f938431-6a22-4fa9-8fcd-b0bfee19d5ae	abd98cd1-f901-4fdd-8033-e31918f28156	9	6	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:51:30.159869+03:30
bef12f12-635c-41c5-a089-2e4a94499807	fe2f0d66-c34e-4549-a690-a09caa05653b	abd98cd1-f901-4fdd-8033-e31918f28156	9	8	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:51:30.159869+03:30
f1516430-fb2f-4661-a18e-47a33513dcf7	ce7deec6-1bcb-4af1-87b2-4b2b58ae7a99	abd98cd1-f901-4fdd-8033-e31918f28156	9	1	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:51:30.159869+03:30
1b5444bf-8bde-4d33-8724-161a9319af86	3576a8bb-9fd9-438b-8f88-91298f2f7754	abd98cd1-f901-4fdd-8033-e31918f28156	9	3	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:51:30.159869+03:30
b483d505-2026-42d3-beb4-081f74ee60b9	001b06a9-dccb-4065-bc46-2e47752922c6	abd98cd1-f901-4fdd-8033-e31918f28156	9	0	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:51:30.159869+03:30
8630724e-eec8-4cd3-bc68-2199f5e2f9b6	25d9f9ff-8c6a-4b1b-8892-fbc44677d1d8	279a4c76-7b0d-4504-b0a8-c6f2d667afee	9	6	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:54:02.411411+03:30
540403ea-3c03-4327-b3b0-6212599a837d	8f938431-6a22-4fa9-8fcd-b0bfee19d5ae	279a4c76-7b0d-4504-b0a8-c6f2d667afee	9	9	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:54:02.411411+03:30
8f74721f-41de-4903-8e92-e839f4b64f02	fe2f0d66-c34e-4549-a690-a09caa05653b	279a4c76-7b0d-4504-b0a8-c6f2d667afee	9	1	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:54:02.411411+03:30
e813856d-703a-4b43-9bef-a7edc5393768	ce7deec6-1bcb-4af1-87b2-4b2b58ae7a99	279a4c76-7b0d-4504-b0a8-c6f2d667afee	9	4	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:54:02.411411+03:30
88f0e26b-f3cc-4046-ae67-2eede0fe8dae	3576a8bb-9fd9-438b-8f88-91298f2f7754	279a4c76-7b0d-4504-b0a8-c6f2d667afee	9	7	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:54:02.411411+03:30
81ee249b-ede9-44ce-a773-15a6077cf099	39b1bfd0-5db8-44db-a41e-9f859ac67510	279a4c76-7b0d-4504-b0a8-c6f2d667afee	9	2	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:54:02.411411+03:30
e7620601-8abc-40d4-ad33-89666384f697	d9e99ecd-ce8d-47a7-8453-fee350975696	279a4c76-7b0d-4504-b0a8-c6f2d667afee	9	8	2026-09-22 05:51:30.159869+03:30	2026-09-22 05:51:30.159869+03:30	2026-09-29 05:54:02.411411+03:30
\.


--
-- Data for Name: parameter_changes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parameter_changes (id, parameter_id, period_number, scope, action, created_at) FROM stdin;
eff599e5-3f63-490a-a588-cc39d6aef15f	279a4c76-7b0d-4504-b0a8-c6f2d667afee	1	from_here_on	add	2026-09-20 16:09:28.657895+03:30
e45cd71e-90a2-4050-b260-c4e121a70421	f482a4c1-4877-4041-b2f8-13ceb7a40323	1	from_here_on	add	2026-09-20 16:09:31.407127+03:30
de565c23-230c-41eb-a939-4386e8ad3610	abd98cd1-f901-4fdd-8033-e31918f28156	5	from_here_on	add	2026-09-20 16:09:35.996339+03:30
a40065bb-825b-450f-a4a0-1f759cf37339	f482a4c1-4877-4041-b2f8-13ceb7a40323	10	from_here_on	remove	2026-09-20 16:09:49.460936+03:30
5b16bad8-ace1-4b8c-837f-1e56ed6c43df	447dbe4e-2595-4f0b-bea9-1030bb75333c	9	from_here_on	add	2026-09-20 22:12:55.37583+03:30
da41bc5d-1f84-4435-976e-4c6b174fa815	447dbe4e-2595-4f0b-bea9-1030bb75333c	8	from_here_on	add	2026-09-20 22:13:04.405018+03:30
39a70637-aa05-48ca-9170-c1058dea89e9	d86df7c7-04c7-448b-b133-10b4756173e1	8	from_here_on	add	2026-09-20 22:14:12.451238+03:30
e052af94-6e88-4adb-9744-fd36fc87686d	d86df7c7-04c7-448b-b133-10b4756173e1	9	this_period_only	remove	2026-09-21 01:36:05.30041+03:30
ad0bcce7-5dcf-439e-9c86-020b855e3e45	006628be-1f2b-4a93-addb-59e2624b9da2	1	from_here_on	add	2026-09-22 06:02:37.695511+03:30
\.


--
-- Data for Name: parameters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parameters (id, name, unit, min_value, max_value, sort_order, created_at) FROM stdin;
f482a4c1-4877-4041-b2f8-13ceb7a40323	Rhythm	\N	0	10	2	2026-09-20 16:09:31.407127+03:30
abd98cd1-f901-4fdd-8033-e31918f28156	Balance	points	0	10	3	2026-09-20 16:09:35.996339+03:30
279a4c76-7b0d-4504-b0a8-c6f2d667afee	Speed	\N	0	10	1	2026-09-20 16:09:28.657895+03:30
447dbe4e-2595-4f0b-bea9-1030bb75333c	Run	\N	\N	\N	5	2026-09-20 22:11:48.796992+03:30
d86df7c7-04c7-448b-b133-10b4756173e1	Test Skill	verbals	0	10	4	2026-09-20 21:51:30.641466+03:30
006628be-1f2b-4a93-addb-59e2624b9da2	x	\N	\N	\N	6	2026-09-22 06:02:37.695511+03:30
\.


--
-- Data for Name: saved_views; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_views (id, user_id, name, config, created_at, updated_at) FROM stdin;
ff295efe-e310-4979-a46b-cb62ffc16f1a	05fd9481-3ecb-4926-a04e-ba254699da4e	needs attention	{"sort": {"key": "279a4c76-7b0d-4504-b0a8-c6f2d667afee", "direction": "asc"}, "search": "", "filters": [{"op": "lt", "value": 5, "parameterId": "279a4c76-7b0d-4504-b0a8-c6f2d667afee"}], "periodMode": "current", "showChange": true, "parameterIds": ["279a4c76-7b0d-4504-b0a8-c6f2d667afee", "447dbe4e-2595-4f0b-bea9-1030bb75333c"], "periodNumber": null}	2026-09-22 04:47:11.852652+03:30	2026-09-22 04:47:11.852652+03:30
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (filename, applied_at) FROM stdin;
001_create_students.sql	2026-09-20 15:23:23.281598+03:30
002_create_settings.sql	2026-09-20 15:55:49.942331+03:30
003_create_parameters.sql	2026-09-20 16:06:44.981116+03:30
004_create_evaluations.sql	2026-09-20 21:26:56.89793+03:30
005_create_users_and_sessions.sql	2026-09-21 00:45:01.166012+03:30
006_create_audit_log.sql	2026-09-21 01:27:32.405032+03:30
007_add_score_locks.sql	2026-09-21 17:35:17.954348+03:30
008_create_user_preferences.sql	2026-09-21 17:56:29.132212+03:30
009_create_saved_views.sql	2026-09-21 18:33:45.038699+03:30
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (key, value, updated_at) FROM stdin;
period_anchor_date	2026-07-25	2026-09-20 21:44:55.544587+03:30
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.students (id, student_code, full_name, created_at, deleted_at) FROM stdin;
ce7deec6-1bcb-4af1-87b2-4b2b58ae7a99	CFJS4PLC	Ana Souza	2026-09-20 15:35:33.674861+03:30	\N
01dbb7d8-6ca7-4f8b-8143-443b40a12fb0	2LX6Y3FP	Renamed Student	2026-09-20 15:36:49.914875+03:30	2026-09-20 15:42:41.02529+03:30
0af19126-b42f-44f4-9c03-e7b645259ba3	JFPRYAGJ	Ana Rousi	2026-09-20 15:50:38.245572+03:30	\N
87273563-4bb8-46d5-ad4f-0bdcbdffbc3e	9W5LLR93	Maria Lopez	2026-09-20 15:29:41.899598+03:30	2026-09-20 15:52:16.475804+03:30
fc48ec4f-4d5e-4335-aba6-5d6a1bc3ecd9	NQ83EPDD	an dk	2026-09-20 15:52:33.407775+03:30	2026-09-20 15:52:38.621138+03:30
a18cbae9-8c2d-4b3b-8cc3-90d391912901	8DZY2NDY	Maria Lopez	2026-09-20 15:29:10.518015+03:30	2026-09-20 15:52:47.252666+03:30
cc47388b-00aa-4d59-a46e-446f4eb7452d	M8CMQS6A	Maria Lopez	2026-09-20 15:52:43.769367+03:30	\N
fdd7d6dd-e9a6-44fd-affb-a96366b88e2a	YXS5SPPP	Staff Made Student	2026-09-21 00:56:49.066543+03:30	2026-09-21 01:35:19.902112+03:30
24ae584a-563a-47d0-bee7-faa20fe36cfc	BH4UCBZ6	Mind Of	2026-09-20 22:30:27.708407+03:30	\N
1ada8d71-f3d8-499f-94dc-14b444a0152a	JEMH6XF4	ff fff	2026-09-21 01:35:34.005577+03:30	\N
b36da6ba-aa44-4083-929c-0fb31c5b36cb	KPJLZUTU	Audit Test Student	2026-09-21 01:30:10.27911+03:30	2026-09-21 03:58:27.563797+03:30
66320df3-f60c-4e59-8e14-d75d994c3d29	YM3S5AQ4	Nadia Kowalski	2026-09-22 05:01:35.791456+03:30	\N
76f918c5-706c-4e4e-8384-06c095234340	2EM9KGER	Nadia Kowalski	2026-09-22 05:01:35.835949+03:30	\N
a18e8ab5-ec6c-436e-b42d-2b188775684a	4HVRRYP3	João Silva	2026-09-22 05:14:44.065747+03:30	\N
19bba15a-cfb6-42b9-a4ec-3b08b5f9f627	M76M3X6V	O'Brien, Pat Jr	2026-09-22 05:14:44.065747+03:30	\N
39b1bfd0-5db8-44db-a41e-9f859ac67510	2H9PTKFP	=HYPERLINK("http://example.com") Test	2026-09-22 05:14:44.065747+03:30	\N
165219bb-20d6-40bd-8c41-0acf266f5f38	QSZCABLG	Zoë Müller	2026-09-22 05:14:44.065747+03:30	\N
1807bd91-8a0c-477e-9a0e-1b31bf72a5a2	AQ6ZKAQD	Maria Lopez	2026-09-22 05:15:47.499002+03:30	\N
41733feb-48c6-4623-9819-1bee2d09199c	7LYH3QDS	João Silva	2026-09-22 05:15:47.499002+03:30	\N
3576a8bb-9fd9-438b-8f88-91298f2f7754	RS7KLGC6	Ana Souza	2026-09-22 05:15:47.499002+03:30	\N
fe2f0d66-c34e-4549-a690-a09caa05653b	5XSBBX92	Ana Souza	2026-09-22 05:15:47.499002+03:30	\N
2c932cc4-461b-4f0f-b892-f9a41b349ee8	XWYZRTEH	O'Brien, Pat Jr	2026-09-22 05:15:47.499002+03:30	\N
001b06a9-dccb-4065-bc46-2e47752922c6	RDM9HX4H	=HYPERLINK("http://example.com") Test	2026-09-22 05:15:47.499002+03:30	\N
421dc94f-e004-44d6-bbc2-507122f58a3f	N2YZPB99	Zoë Müller	2026-09-22 05:15:47.499002+03:30	\N
bf4c66f4-eee4-46ed-adf8-da64edd97746	2ATLUWYP	Maria Lopez	2026-09-22 05:16:16.129151+03:30	\N
c12b4156-491b-4483-b5ac-e566d9b3590e	FL2VYFXT	João Silva	2026-09-22 05:16:16.129151+03:30	\N
25d9f9ff-8c6a-4b1b-8892-fbc44677d1d8	FK7PD5BQ	Ana Souza	2026-09-22 05:16:16.129151+03:30	\N
8f938431-6a22-4fa9-8fcd-b0bfee19d5ae	TCBPFT6K	Ana Souza	2026-09-22 05:16:16.129151+03:30	\N
62b6ae93-29be-47d3-b369-d7fe8306a119	Q4EV79VX	O'Brien, Pat Jr	2026-09-22 05:16:16.129151+03:30	\N
d9e99ecd-ce8d-47a7-8453-fee350975696	UFPFXL8H	=HYPERLINK("http://example.com") Test	2026-09-22 05:16:16.129151+03:30	\N
13983db8-9025-4349-8a04-742c11439a60	LYVXHJ8E	Zoë Müller	2026-09-22 05:16:16.129151+03:30	\N
694bbf06-9389-43c6-a71b-22a9f5c0bf8c	GFMJNB7T	Permission Test	2026-09-22 06:02:37.657096+03:30	\N
8fda872c-6912-4e38-bab2-d00c74bb9543	5A9J63T6	Permission Test	2026-09-22 06:04:50.698135+03:30	\N
52464aec-a67d-445a-aa64-759df991295c	37ZMBKK7	Permission Test	2026-09-22 06:09:10.550647+03:30	\N
4e8a2c57-c48e-4a79-970c-efc402f55e08	7ZQJUTPH	Test Walkthrough One1	2026-09-22 06:18:43.756176+03:30	\N
a168a2ff-75aa-48f0-bdf8-a12fa6af32fa	2DT8L9UH	Test Walkthrough One	2026-09-22 06:18:57.867863+03:30	2026-09-22 06:19:27.635212+03:30
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_preferences (user_id, settings, updated_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (sid, sess, expire) FROM stdin;
-Da7b558q0loMa4vbRIARPC_VV-dRS5D	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T09:29:54.730Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 12:59:59
zEL3bT5zcEXpZhzH7ZOeSy7ladRiE57c	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T10:32:37.183Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 14:02:38
h0puQ8y-YJCqp0EelgkpAagnWy-DRA_D	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T10:47:27.050Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 14:23:09
ZfuxsnWCY1Bf1ws6r58UxxiKaikXKthR	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T09:20:25.472Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 12:54:50
S9yQE4FzMPPMDp3fjRMB5rcCNxI0bJpK	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T09:29:10.708Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 12:59:11
ZExYG2Yr7cvCOuX57-Bb-Jf_wGo5Ov2O	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T09:31:05.324Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 13:01:43
DgR3BDpDaXsClpYVUjAz2Ba1U1viEPYF	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T09:52:26.599Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 13:53:51
QHQfyYmgxu1AT5icya1BVudpe5GWUHSn	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T10:39:10.233Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"6244afeb-a488-475a-92e8-d5b792b9cec4"}	2026-09-22 14:09:11
TCns4t1pOORWeM9toOVYv0PFY3801WrA	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T10:34:50.230Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 14:04:51
CFcQYjhtUBX7S7OVDttIX1ybhb4C6G8j	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T10:32:37.536Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"6244afeb-a488-475a-92e8-d5b792b9cec4"}	2026-09-22 14:02:38
wGDhviyEtZY_f20YpF5yJAdX7YUIucz2	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T10:34:15.475Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 14:04:16
5i8GC6v_G2jYj7CgUYXCurcd1XV_YCu-	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T10:32:37.376Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"0f79b04f-4723-4f45-90a2-b0cf72ec5dcc"}	2026-09-22 14:02:38
iIe-VbPspXQ7tTwbOiw_1rwmPfbCA_PL	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T10:39:10.056Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"0f79b04f-4723-4f45-90a2-b0cf72ec5dcc"}	2026-09-22 14:09:11
zcFYp50k6IIAPKs9yDrQzjdNx_rO3vqi	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T10:34:50.574Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"6244afeb-a488-475a-92e8-d5b792b9cec4"}	2026-09-22 14:04:51
yG6mHipwujCER8_aUk-Swg14p1Bg6tLm	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T10:34:50.415Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"0f79b04f-4723-4f45-90a2-b0cf72ec5dcc"}	2026-09-22 14:04:51
DLccK3dLeBo8kdZINSf4ureGg0ROEPWW	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T04:14:22.512Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 07:44:34
gw4gnkRhE0OwOcFWpIsFJ7pMBs_WdZKL	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T10:39:09.853Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 14:09:11
P8mKhwmMLLQQo3QrfvpcnZk6HvclbNTi	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T04:15:27.019Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 07:49:02
8q_KgSHIe3o0C6ar8PkGF8_3ziOTMeGt	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T04:21:33.147Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 07:51:38
UKLpHW7Csdz_j2_s7vP12noxJYHANMmo	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T04:33:29.212Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 08:03:35
_HHaehaOmwrIDZy8gRNhM7UiUxAplQwW	{"cookie":{"originalMaxAge":28800000,"expires":"2026-09-22T04:33:57.779Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"05fd9481-3ecb-4926-a04e-ba254699da4e"}	2026-09-22 08:04:28
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, full_name, password_hash, role, is_active, must_change_password, last_login_at, created_at, updated_at) FROM stdin;
76f5cba1-ffdb-4257-8da0-6e4f73a7d429	temp1	Temp User	$argon2id$v=19$m=65536,p=4,t=3$nr/V9oKPT97BS/+hljx23Q$stgHDOOq5/p0SoXqiodq+2wfZoy45xbBTzTmutCXdN0	staff	t	f	2026-09-21 01:24:41.118387+03:30	2026-09-21 01:23:28.252522+03:30	2026-09-21 01:24:26.031367+03:30
70565337-2fea-47a1-8aed-ae270f79a594	teacher2	TOmas STaff	$argon2id$v=19$m=65536,p=4,t=3$6kw+pydIjYuk2KyQxGfyTg$s1QdnURSmQBlq+3b8abq9oJpelf0v/qzK62KF0ta1JU	staff	t	f	2026-09-21 17:32:37.412052+03:30	2026-09-21 17:23:19.903864+03:30	2026-09-21 17:32:51.7192+03:30
38f8b39c-d3ed-406a-af9b-173179079f28	teacher1	Tina Teacher	$argon2id$v=19$m=65536,p=4,t=3$AhdmKGpwqzwmcjZq+p8vCg$B+INpq2BrZgSVSkelcIRhizbCUuZYqkMJQhsoIDecDY	staff	t	t	\N	2026-09-21 17:06:11.674816+03:30	2026-09-21 17:06:11.674816+03:30
0f79b04f-4723-4f45-90a2-b0cf72ec5dcc	staff1	Sam Staff	$argon2id$v=19$m=65536,p=4,t=3$73UDYJb2I4fz10lvKnEu5w$+37FUut9QhdmgC4dxjmap8ZMc+6GKpeXOvO1t5XqjmE	staff	t	f	2026-09-22 06:09:10.052816+03:30	2026-09-21 00:55:10.31599+03:30	2026-09-21 01:43:44.513704+03:30
6244afeb-a488-475a-92e8-d5b792b9cec4	viewer1	Vera Viewer	$argon2id$v=19$m=65536,p=4,t=3$TiGbFnKPJOiwiZW4qpIZbA$8O1iarZ7NfQ+pHfiKHKA7QiveA8VG6k+Dojs0DkvGKQ	viewer	t	f	2026-09-22 06:09:10.229627+03:30	2026-09-21 00:55:10.708497+03:30	2026-09-22 06:01:37.360954+03:30
05fd9481-3ecb-4926-a04e-ba254699da4e	admin	Site Admin	$argon2id$v=19$m=65536,p=4,t=3$cqF8pN4u8LuFUN+Gb1SJgw$NnAQqspv8MaLS3kg2Nf5IZ/ll5P2u8vvX0+QN0bFMqs	admin	t	f	2026-09-22 06:17:27.045992+03:30	2026-09-21 00:50:00.242914+03:30	2026-09-21 17:07:11.606661+03:30
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 136, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: evaluations evaluations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_pkey PRIMARY KEY (id);


--
-- Name: evaluations evaluations_student_id_parameter_id_period_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_student_id_parameter_id_period_number_key UNIQUE (student_id, parameter_id, period_number);


--
-- Name: parameter_changes parameter_changes_parameter_id_period_number_scope_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parameter_changes
    ADD CONSTRAINT parameter_changes_parameter_id_period_number_scope_key UNIQUE (parameter_id, period_number, scope);


--
-- Name: parameter_changes parameter_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parameter_changes
    ADD CONSTRAINT parameter_changes_pkey PRIMARY KEY (id);


--
-- Name: parameters parameters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parameters
    ADD CONSTRAINT parameters_pkey PRIMARY KEY (id);


--
-- Name: saved_views saved_views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_views
    ADD CONSTRAINT saved_views_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (filename);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: students students_student_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_student_code_key UNIQUE (student_code);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (user_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (sid);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: audit_log_entity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_entity_idx ON public.audit_log USING btree (entity_type, entity_id);


--
-- Name: audit_log_occurred_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_occurred_idx ON public.audit_log USING btree (occurred_at DESC, id DESC);


--
-- Name: audit_log_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_user_idx ON public.audit_log USING btree (user_id);


--
-- Name: evaluations_parameter_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evaluations_parameter_idx ON public.evaluations USING btree (parameter_id);


--
-- Name: evaluations_period_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evaluations_period_idx ON public.evaluations USING btree (period_number);


--
-- Name: parameters_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX parameters_name_unique ON public.parameters USING btree (lower(name));


--
-- Name: saved_views_user_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX saved_views_user_name_unique ON public.saved_views USING btree (user_id, lower(name));


--
-- Name: user_sessions_expire_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_expire_idx ON public.user_sessions USING btree (expire);


--
-- Name: users_username_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_username_unique ON public.users USING btree (lower(username));


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: evaluations evaluations_parameter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_parameter_id_fkey FOREIGN KEY (parameter_id) REFERENCES public.parameters(id);


--
-- Name: evaluations evaluations_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: parameter_changes parameter_changes_parameter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parameter_changes
    ADD CONSTRAINT parameter_changes_parameter_id_fkey FOREIGN KEY (parameter_id) REFERENCES public.parameters(id);


--
-- Name: saved_views saved_views_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_views
    ADD CONSTRAINT saved_views_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_preferences user_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict h6TlP8SXv3k9SWz7NR9u3uEdfoK1MpBTO6TIDtALHAApazPjrD3VVEJ2Xj4vvQc

